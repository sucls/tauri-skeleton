export { setAssetPath, setPlatformOptions } from '@stencil/core/internal/client';
export { IonIcon, a as addIcons, defineCustomElement as defineCustomElementIonIcon } from './ion-icon.js';
